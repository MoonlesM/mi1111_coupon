// ==UserScript==
// @name         小米1111 搶折價卷
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  try to take over the world!
// @author       Leo
// @match        https://event.mi.com/tw/sales2018/super-sales-day
// @include      https://event.mi.com/tw/sales2018/*
// @grant        none
// @require http://code.jquery.com/jquery-3.3.1.min.js
// ==/UserScript==

(function() {
    'use strict';
  //  while(i<10) {
  //   alert("test");
  //  alert = function(){};
    // alert("test");
    window.addEventListener('load', function() {
    $(".J_couponArea").removeAttr("disabled");
    $(".J_couponArea" ).click(function() {
    $( this ).click();
    });
    }, false);
 //   i++;
 //   }
})();